package com.example.atividadetabuada;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button btn;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.input);
        btn = findViewById(R.id.sendbtn);
        listView = findViewById(R.id.listinha);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tabuada(editText.getText().toString());
            }
        });
    }

    private void tabuada(String n){
        int nn = Integer.parseInt(n);
        ArrayList<String> dados = new ArrayList<String>();
        ArrayAdapter<String> adapter;

        for(int i = 1; i <= 10; i++){
            dados.add(nn + " x " + i + " = " + nn*i);
        }

        adapter = new ArrayAdapter<String>(MainActivity.this, R.layout.list_view, dados);
        listView.setAdapter(adapter);
    }
}
